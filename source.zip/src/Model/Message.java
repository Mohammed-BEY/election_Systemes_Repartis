/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.net.InetAddress;
import java.net.Socket;

/**
 *
 * @author walid y
 */
public class Message {
    private int idSource; // l'identifiant du processus emetteur du message 
    private int idDestination; // l'identifiant du processus recepteur du message
    private TypeMessage type ; // le type de message envoyé
    InetAddress IPAddressCleint;
    int portClient;
    
    
    public Message(int idSource, int idDestination, TypeMessage type) {
        this.idSource = idSource;
        this.idDestination = idDestination;
        this.type = type;
    }

    public Message() {
    }

    
    public int getIdSource() {
        return idSource;
    }

    public void setIdSource(int idSource) {
        this.idSource = idSource;
    }

    public int getIdDestination() {
        return idDestination;
    }

    public void setIdDestination(int idDestination) {
        this.idDestination = idDestination;
    }

    public TypeMessage getType() {
        return type;
    }

    public void setType(TypeMessage type) {
        this.type = type;
    }

    public InetAddress getIPAddressCleint() {
        return IPAddressCleint;
    }

    public void setIPAddressCleint(InetAddress IPAddressCleint) {
        this.IPAddressCleint = IPAddressCleint;
    }

    public int getPortClient() {
        return portClient;
    }

    public void setPortClient(int portClient) {
        this.portClient = portClient;
    }

    @Override
    public String toString() {
        String message_string = ""; // la chaine a envoyée du serveur vers le client 
        message_string = message_string.concat("" + type + "-" + idSource + "-" + idDestination); // construire le message à envoyer
        return message_string;
    }


    
    
    
    
}
