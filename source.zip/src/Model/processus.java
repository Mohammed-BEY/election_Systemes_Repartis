/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.net.InetAddress;

/**
 *
 * @author walid y
 */
public class processus {
    private int id;
    private InetAddress addressSite;
    private int portSite;

    public processus(int id, InetAddress addressSite, int portSite) {
        this.id = id;
        this.addressSite = addressSite;
        this.portSite = portSite;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public InetAddress getAddressSite() {
        return addressSite;
    }

    public void setAddressSite(InetAddress addressSite) {
        this.addressSite = addressSite;
    }

    public int getPortSite() {
        return portSite;
    }

    public void setPortSite(int portSite) {
        this.portSite = portSite;
    }
    
    
}
