package TP_SystR;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.jfoenix.controls.JFXTextArea;
import java.awt.Toolkit;
import java.io.IOException;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author mohammed
 */
public class WindowClass {

    Thread thProgressBar;
    private final String styleLabelEtatEnCours = "-fx-text-fill: greenyellow;\n" + "-fx-background-color: white;\n" + "-fx-font-size: 18pt;",
            labelEtatBloque = "-fx-text-fill: red;\n" + "    -fx-background-color: white;\n" + "-fx-font-size: 18pt;",
            styleCoordinateur = "-fx-background-color: white;\n" + "-fx-border-color: red;\n" + "-fx-border-width: 3;",
            styleLabelEtat = "-fx-font-size: 18pt;",
            styleBackground = "-fx-background-color: white;",
            styleTextArea = "-fx-border-color: black;\n" + "-fx-border-width: 1.5;\n" + "-fx-background-color:white;",
            styleCircleIndicateur = "-fx-fill:blue;",
            styleCircleCoordinateur = "-fx-fill:greenyellow;";
    static final int WIDTH = Toolkit.getDefaultToolkit().getScreenSize().width / 5,
            HEIGHT = Toolkit.getDefaultToolkit().getScreenSize().height / 2;
    FXMLLoader loader;
    JFXTextArea taTrace;
    Label labelID, labelEtat, labelEtatMAJ;
    ProgressIndicator indicateurEtatAttente;
    Circle circleIndicator, circleCoordinateur;
    final StackPane stack;
    BooleanProperty etatProcessDisplay = new SimpleBooleanProperty(true);
    Task copyWorker;
    Thread th;
    AnchorPane root;
    Stage primaryStage;
    Scene scene;
    private int numeroSite;

    public ProgressIndicator getIndicateurEtatAttente() {
        return indicateurEtatAttente;
    }

    public WindowClass(int id, double posX, double posY) throws IOException {
        this.numeroSite = id;
        root = new AnchorPane();
        Stage primaryStage = new Stage();
        Scene scene = new Scene(root, WIDTH - 20, HEIGHT);
//        String css = this.getClass().getResource("JMetroLightTheme.css").toExternalForm();
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);

        //----Ajout des éléments
        indicateurEtatAttente = new ProgressIndicator();
        indicateurEtatAttente.setPrefSize(70, 70);

        circleIndicator = new Circle(35);
//        circleIndicator = new Circle(35, Color.rgb(156, 216, 255));
        circleIndicator.setEffect(new Lighting());
        circleIndicator.setStyle(styleCircleIndicateur);
        //create a text inside a circle
        final Text text = new Text(" SC ");
        text.setStyle(styleLabelEtat);
        text.setStroke(Color.GREENYELLOW);
        //create a layout for circle with text inside
        stack = new StackPane();
        stack.getChildren().addAll(circleIndicator, text);
        stack.setVisible(false);

        circleCoordinateur = new Circle(19);
        circleCoordinateur.setVisible(false);
        circleCoordinateur.setEffect(new Lighting());
        circleCoordinateur.setStyle(styleCircleCoordinateur);

        labelID = new Label("Site : " + id);
        labelID.setStyle(styleLabelEtat);

        labelEtat = new Label("État :");
        labelEtat.setStyle(styleLabelEtat);

        labelEtatMAJ = new Label();

        taTrace = new JFXTextArea();
        taTrace.setEditable(false);
        taTrace.setPrefSize(WIDTH - 14 * 2, 250);
        taTrace.setStyle(styleTextArea);

        root.getChildren().addAll(circleCoordinateur, labelID, labelEtat, labelEtatMAJ, indicateurEtatAttente, stack, taTrace);
        root.setStyle(styleBackground);

        //--Positionnement des éléments dans la fenêtre
        circleCoordinateur.setLayoutX(243);
        circleCoordinateur.setLayoutY(34);

        labelID.setLayoutX(16);
        labelID.setLayoutY(23);

        labelEtat.setLayoutX(16);
        labelEtat.setLayoutY(83);

        labelEtatMAJ.setLayoutX(80);
        labelEtatMAJ.setLayoutY(83);

        indicateurEtatAttente.setLayoutX(190);
        indicateurEtatAttente.setLayoutY(60);

        stack.setLayoutX(190);
        stack.setLayoutY(60);

        taTrace.setLayoutX(9);
        taTrace.setLayoutY(140);

        //--Mise à jour de l'état du prccessus
        etatProcessDisplay.addListener((observable, oldValue, newValue) -> {
            if (!etatProcessDisplay.get()) {
                System.out.println("*************************************En Cours**********************************");
                labelEtatMAJ.setText(" En cours");
                labelEtatMAJ.getStylesheets().clear();
                labelEtatMAJ.setStyle(styleLabelEtatEnCours);
                this.stack.setVisible(true);
                this.indicateurEtatAttente.setVisible(false);
//                indicateurEtatAttente = new ProgressIndicator(0);
//                indicateurEtatAttente.setPrefSize(70, 70);
//                root.getChildren().remove(3);
//                root.getChildren().add(3, indicateurEtatAttente);
//                indicateurEtatAttente.setProgress(0);
//                indicateurEtatAttente.setLayoutX(190);
//                indicateurEtatAttente.setLayoutY(60);
//                copyWorker = createWorker();
////                indicateurEtatAttente.progressProperty().unbind();
//                indicateurEtatAttente.progressProperty().bind(copyWorker.progressProperty());
//                thProgressBar = new Thread(copyWorker);
//                thProgressBar.start();
            } else {
                System.out.println("----------------------------------------En attente!!!------------------------------");
                labelEtatMAJ.setText(" En panne");
                labelEtatMAJ.getStylesheets().clear();
                labelEtatMAJ.setStyle(labelEtatBloque);

                this.stack.setVisible(false);
                this.indicateurEtatAttente.setVisible(true);

//                indicateurEtatAttente = new ProgressIndicator();
//                indicateurEtatAttente.setPrefSize(70, 70);
//                root.getChildren().remove(3);
//                root.getChildren().add(3, indicateurEtatAttente);
//                indicateurEtatAttente.setLayoutX(190);
//                indicateurEtatAttente.setLayoutY(60);
//                Thread thread = new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        for (int i = 1; i <= 100; i++) {
//                            final int counter = i;
//                            Platform.runLater(new Runnable() {
//                                @Override
//                                public void run() {
//                                    indicateurEtatAttente.setProgress(counter);
//                                    System.out.println("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
//                                }
//                            });
//                        }
//                    }
//                });
//                thread.start();
            }
        });

        primaryStage.setX(posX);
        primaryStage.setY(posY);
        primaryStage.show();
    }

    public Task createWorker() {
        return new Task() {
            @Override
            protected Object call() throws Exception {
                for (int i = 0; i < 20; i++) {
                    Thread.sleep(100);//100ms
                    updateProgress(i + 1, 20);
                }
                if (!thProgressBar.isAlive()) {
                    thProgressBar.stop();
                }
                return true;
            }
        };
    }

    public void ecrireMessageTrace(String message) {
        String tmp = taTrace.getText();
        taTrace.setText(tmp + message + "\n");
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public Scene getScene() {
        return scene;
    }

    public AnchorPane getRoot() {
        return root;
    }

    public void modifierStyleShow() {
        this.circleCoordinateur.setVisible(true);
    }

    public void modifierStyleHide() {
        this.circleCoordinateur.setVisible(false);
    }
}
