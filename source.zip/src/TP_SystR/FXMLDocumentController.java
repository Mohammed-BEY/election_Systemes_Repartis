/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_SystR;

import Algorithme.Site;
import Algorithme.Test;
import static Algorithme.Test.IDServeur;
import static Algorithme.Test.probatPann;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;

/**
 *
 * @author walid y
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Spinner nombre_site_spinner;
    @FXML
    private Label probat_pan_label, tmps_SC_label, tmps_pan_labell;
    @FXML
    private Slider probat_pan_slider, temps_SC_slider, temps_pan_slider;

    public static WindowClass[] windows = new WindowClass[10];
    Thread[] listThread = new Thread[10];

    @FXML
    public void LancerSimulation() {
        Test.Nbr_Site = (Integer.parseInt(this.nombre_site_spinner.getEditor().getText()));
        Test.probatPann = this.probat_pan_slider.getValue();
        Test.IDServeur = Test.Nbr_Site - 1;

        System.out.println(" Test nbr de psite " + Test.Nbr_Site);
        for (int i = 0; i < 5; i++) {
            try {
                windows[i] = new WindowClass(i, i * WindowClass.WIDTH, 0);
            } catch (IOException ex) {

            }
        }

        for (int j = 5; j < 10; j++) {
            try {
                windows[j] = new WindowClass(j, (j - 5) * WindowClass.WIDTH, WindowClass.HEIGHT);
            } catch (IOException ex) {

            }
        }
        for (int k = 0; k < Test.Nbr_Site; k++) {
            Site s0 = new Site(false, k, IDServeur, probatPann, windows[k]);
            if (k == Test.IDServeur) {
                s0.setJeSuisCoord(true);
            }
            windows[k].etatProcessDisplay.bind(s0.JeSuisEnPanneP);
            listThread[k] = new Thread(s0);
        }
        for (int k = 0; k < Test.Nbr_Site; k++) {
            listThread[k].start();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        try {
//            WindowClass window = new WindowClass(0, 0, 0);
//        } catch (IOException ex) {
//        }
        // Init le spinner
        nombre_site_spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10));
        // nombre_site_spinner.setUserData(10);
        nombre_site_spinner.setEditable(true);
        // Faire le binfings entre les label et les sliders

        probat_pan_label.textProperty().bind(probat_pan_slider.valueProperty().asString());

        tmps_SC_label.textProperty().bind(temps_SC_slider.valueProperty().asString());
        tmps_pan_labell.textProperty().bind(temps_pan_slider.valueProperty().asString());

    }

    @FXML
    public void Quitter() {
        for (int i = 0; i < 10; i++) {
            listThread[i].stop();
        }
        System.exit(0);
    }

}
