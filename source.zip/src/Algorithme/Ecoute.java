/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Algorithme;

import Model.Message;
import Model.TypeMessage;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author walid y
 */
public class Ecoute implements Runnable {

    DatagramSocket sockServeur;
    DatagramPacket receivedPaquet;
    ArrayList<Message> ListREQ;
    Site site;
    
    InetAddress IPAddressCleint; 
    int portClient ;
    DatagramPacket sendPacket;   
    
    public Ecoute(DatagramSocket sockServeur, ArrayList<Message> ListREQ, Site site) {
        this.sockServeur = sockServeur;
        this.ListREQ = ListREQ;
        this.site = site;
    }

    @Override
    public void run() {
        byte[] receiveData = new byte[1024];
        byte[] sendData = new byte[1024];
        receivedPaquet = new DatagramPacket(receiveData, receiveData.length);
        Message msgR = null;
        Message msgE = new Message();
        while (true) {
            try {
                // REcevoir un paquet
                sockServeur.receive(receivedPaquet);
                // constrruir un message
                msgR = ByteToMessage(receivedPaquet.getData());
                msgR.setIPAddressCleint(receivedPaquet.getAddress());
                msgR.setPortClient(receivedPaquet.getPort());

                System.out.println(" SERVEUR : ecoute " + msgR.toString());

                if (msgR.getType() == TypeMessage.REQ || msgR.getType() == TypeMessage.LIB) {
                    synchronized (this.ListREQ) {
                        ListREQ.add(msgR);
                        ListREQ.notifyAll();
                    }
                } else {
                    if (msgR.getType() == TypeMessage.ACK && this.site.IdLAstProcessusAutorise==msgR.getIdSource()) {
                        this.site.ClientEnPanne = false;
                    }
                    if (msgR.getType() == TypeMessage.PANNE && this.site.IdLAstProcessusAutorise==msgR.getIdSource()) {
                        System.out.println(" SERVEUR : Client " + msgR.getIdSource() + " EST EN PANNE " + this.site.getFile().get(0).getId());
                        this.site.ClientEnPanne = true;
                        this.site.autorise = false;
                        this.site.removeProcessFile(msgR.getIdSource());
                    }
                    if(msgR.getType() == TypeMessage.ELECTION){
                        this.site.serveurEnPanne = true;
                        
                        if(!this.site.JeSuisEnPanne){ // si je ne suis pas en panne je répond par Ok 
                            msgE.setIPAddressCleint(msgR.getIPAddressCleint());
                            msgE.setPortClient(msgR.getPortClient());
                            msgE.setIdDestination(msgR.getIdSource());
                            msgE.setIdSource(msgR.getIdDestination());
                            msgE.setType(TypeMessage.OK);
                            sendData = MessageToByte(msgE);

                            IPAddressCleint = msgR.getIPAddressCleint();
                            portClient = msgR.getPortClient();
                            
                            // créer le paquet à transmettre 
                            sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressCleint, portClient);
                            sockServeur.send(sendPacket);
                        }
                    }
                    if(msgR.getType() == TypeMessage.OK){
                        this.site.nbrRepRecues ++ ;
                    }
                    if(msgR.getType() == TypeMessage.COORDINATEUR){
                        this.site.finElection = true;
                        this.site.IDServeur = msgR.getIdSource();
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(Ecoute.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    public Message ByteToMessage(byte[] mesgb) {

        String mesg = new String(mesgb);
        Message message = new Message();
        // System.out.println("taille message reçu  "+mesg.length());
        String[] Tmp = mesg.split("-");
        // System.out.println(" "+Tmp[2]+ " -taille "+Tmp[2].length());

        message.setType(TypeMessage.valueOf(Tmp[0]));
        message.setIdSource(Integer.parseInt(Tmp[1]));
        message.setIdDestination(Integer.parseInt(Tmp[2]));

        return message;
    }

    public byte[] MessageToByte(Message message) {
        String message_string = ""; // la chaine a envoyée du serveur vers le client 
        message_string = message_string.concat("" + message.getType() + "-" + message.getIdSource() + "-" + message.getIdDestination() + "-"); // construire le message à envoyer

        return message_string.getBytes();
    }
}
