/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Algorithme;


import TP_SystR.WindowClass;
import java.io.IOException;

/**
 *
 * @author walid y
 */
public class Test {

    public static int IDServeur=9;
    public static int Nbr_Site =10;
    public static int Num_portServeur = 2000;
    public static double probatPann =0.5;
    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) throws IOException {
//        // TODO code application logic here
//        WindowClass[] windows = new WindowClass[10];
//        
//        Site s0 = new Site(true, 0, IDServeur,probatPann);
//        Site s1 = new Site(false, 1, IDServeur,probatPann);
//        Site s2 = new Site(false, 2, IDServeur,probatPann);
//        Site s3 = new Site(false, 3, IDServeur,probatPann);
//        
//        Thread th1 = new Thread(s0);
//        th1.start();
//        
//        Thread th2 = new Thread(s1);
//        th2.start();
//     
//     
//     Thread th3 = new Thread(s2);
//     th3.start();
//      
//      Thread th4 = new Thread(s3);
//      th4.start();
//      windows[0] = new WindowClass(0,0*WindowClass.WIDTH,0);
      
//      for(int i =0;i<5;i++){
//            try {
//                windows[i] = new WindowClass(i,i*WindowClass.WIDTH,0);
//            } catch (IOException ex) {
//                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
//            }
//      }
//     
//      for(int j =5;j<10;j++){
//          try {
//                windows[j] = new WindowClass(j,(j-5)*WindowClass.WIDTH,WindowClass.HEIGHT);
//            } catch (IOException ex) {
//                Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
//            }
//      }
//        
//    }
    
}
