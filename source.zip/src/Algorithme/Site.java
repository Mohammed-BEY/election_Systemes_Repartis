/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Algorithme;

import Model.Message;
import Model.TypeMessage;
import Model.processus;
import static TP_SystR.FXMLDocumentController.windows;
import TP_SystR.WindowClass;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

/**
 *
 * @author walid y
 */
public class Site implements Runnable {

    private boolean jeSuisCoord;
    private int monID;
    public int IDServeur;
    private ArrayList<processus> file;
    private ArrayList<Message> ListReq;
    DatagramSocket clientSocket;
    InetAddress IPAddress;
    DatagramSocket serverSocket;
    private double probatPanne;

    WindowClass window;
    public boolean serveurEnPanne = false;
    public boolean ClientEnPanne = false;
    public boolean JeSuisEnPanne = false;
    public int IdLAstProcessusAutorise;
    public boolean autorise = false;
    public boolean finElection;
    public int nbrRepRecues;

    public BooleanProperty JeSuisEnPanneP;

    public Site(boolean jeSuisCoord, int monID, int IDServeur, double probaPanne, WindowClass wind) {
        this.jeSuisCoord = jeSuisCoord;
        this.monID = monID;
        this.IDServeur = IDServeur;
        this.ListReq = new ArrayList<>();
        this.file = new ArrayList<>();
        this.probatPanne = probaPanne;
        this.window = wind;

        JeSuisEnPanneP = new SimpleBooleanProperty(false);
    }

    @Override
    public void run() {

        try {
            // Ouvrir le socket du serveur
            this.serverSocket = new DatagramSocket(this.monID + Test.Num_portServeur, InetAddress.getLocalHost());
            this.IPAddress = InetAddress.getByName("localhost");

            // Ouvrir un socket pour le client 
            this.clientSocket = new DatagramSocket();

            byte[] receiveData = new byte[1024];
            byte[] sendData = new byte[1024];
            Message msgR = null;
            Message msgE = new Message();

            InetAddress IPAddressCleint;
            InetAddress IPAddressServeur;
            int portClient;
            int portServeur;

            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            DatagramPacket sendPacket;

            processus idSiteChoisit;

            long delaiAttente, tempSC;

            Thread ecoute = new Thread(new Ecoute(serverSocket, ListReq, this));
            ecoute.start();
            double probatP;

            while (true) {
                if (jeSuisCoord) { // je suis un serveur
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    for (int i = 0; i < 10; i++) {
                        if (this.window.getIndicateurEtatAttente() == ((WindowClass) windows[i]).getIndicateurEtatAttente()) {
                            ((WindowClass) windows[i]).modifierStyleShow();
                        } else {
                            ((WindowClass) windows[i]).modifierStyleHide();
                        }
                    }
                    if (this.ListReq.isEmpty()) {
                        synchronized (this.ListReq) {
                            this.ListReq.wait();
                        }
                    }
                    // Récupéerer un message 
                    msgR = this.ListReq.get(0);
                    this.ListReq.remove(Integer.parseInt("0"));

                    System.out.println("RECEIVED FROM CLIENT " + msgR.getIdSource() + " : " + msgR.toString());
                    if (!JeSuisEnPanne) {
                        window.ecrireMessageTrace("RECEIVED FROM CLIENT " + msgR.getIdSource() + " : " + msgR.toString());
                    }

                    probatP = Math.random();
                    System.out.println(" Probat de panne  serveur = " + probatP);
                    if (probatP < probatPanne) {
                        System.out.println(this.monID + " Serveur Je suis en panne !!");
                        window.ecrireMessageTrace(" JE SUIS EN PANNE ");
                        this.JeSuisEnPanne = true;
                        // System.out.println("*"+ JeSuisEnPanneP.get());
                        JeSuisEnPanneP.set(true);
                    }
                    if (msgR.getType() == TypeMessage.REQ) {
                        this.file.add(new processus(msgR.getIdSource(), msgR.getIPAddressCleint(), msgR.getPortClient()));
                        if (JeSuisEnPanne) { // si je suis  en panne j'envoie un pmsg Panne
                            msgE.setIPAddressCleint(msgR.getIPAddressCleint());
                            msgE.setPortClient(msgR.getPortClient());
                            msgE.setIdDestination(msgR.getIdSource());
                            msgE.setIdSource(this.monID);
                            msgE.setType(TypeMessage.PANNE);
                            sendData = MessageToByte(msgE);

                            IPAddressCleint = msgR.getIPAddressCleint();
                            portClient = msgR.getPortClient();
                            // créer le paquet à transmettre 
                            sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressCleint, portClient);
                            serverSocket.send(sendPacket);

                        } else { // Je ne suis pas en panne pour chaque REQ j'envoie un message ACK
                            msgE.setIPAddressCleint(msgR.getIPAddressCleint());
                            msgE.setPortClient(msgR.getPortClient());
                            msgE.setIdDestination(msgR.getIdSource());
                            msgE.setIdSource(this.monID);
                            msgE.setType(TypeMessage.ACK);
                            sendData = MessageToByte(msgE);

                            IPAddressCleint = msgR.getIPAddressCleint();
                            portClient = msgR.getPortClient();
                            // créer le paquet à transmettre 
                            sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressCleint, portClient);
                            serverSocket.send(sendPacket);

                        }
                    }
                    if (msgR.getType() == TypeMessage.LIB) {
                        if (!this.file.isEmpty()) {
                            this.file.remove(Integer.parseInt("0"));
                        }
                        autorise = false;
                    }

                    if (!this.file.isEmpty() && !JeSuisEnPanne) {
                        if (!autorise) {

                            idSiteChoisit = this.file.get(0);
                            IdLAstProcessusAutorise = idSiteChoisit.getId();

                            msgE.setIPAddressCleint(idSiteChoisit.getAddressSite());
                            msgE.setPortClient(idSiteChoisit.getPortSite());
                            msgE.setIdDestination(idSiteChoisit.getId());
                            msgE.setIdSource(this.monID);
                            msgE.setType(TypeMessage.AUT);
                            sendData = MessageToByte(msgE);

                            IPAddressCleint = idSiteChoisit.getAddressSite();
                            portClient = idSiteChoisit.getPortSite();
                            // créer le paquet à transmettre 
                            sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressCleint, portClient);
                            serverSocket.send(sendPacket);

                            autorise = true;
                            Thread.sleep(2000);
//                            // Attendre un ACK ou une PANNE
//                            serverSocket.receive(receivePacket);
//
//                            msgR = ByteToMessage(receivePacket.getData());
//                            msgR.setIPAddressCleint(receivePacket.getAddress());
//                            msgR.setPortClient(receivePacket.getPort());

//                            if (this.ClientEnPanne) {
//                                this.ClientEnPanne = true;
//                                System.out.println(" SERVEUR : Client " + IdLAstProcessusAutorise + " EST EN PANNE **********  ");
//                                if (!this.file.isEmpty()) {
//                                    this.file.remove(Integer.parseInt("0"));
//                                }
//                                autorise = false;
//                            }
                            this.ClientEnPanne = false;
                        }

                    }

                } else // je suis un client
                {
                    if (!JeSuisEnPanne) {
                        delaiAttente = genererAttenteAlétoire(1, 5) * 1000; // générer un delai compris entre 1000 et 5000 ms;
                        System.out.println("delais = " + delaiAttente);
                        window.ecrireMessageTrace("ATTENTE CLIENT = " + delaiAttente + " ms ");

                        Thread.sleep(delaiAttente); // attendre un delai alétoire

                        msgE.setIdSource(this.monID);
                        msgE.setIdDestination(this.IDServeur);
                        msgE.setType(TypeMessage.REQ);

                        IPAddressServeur = InetAddress.getLocalHost();
                        portServeur = Test.IDServeur + Test.Num_portServeur;

                        msgE.setIPAddressCleint(IPAddressServeur);
                        msgE.setPortClient(portServeur);

                        sendData = MessageToByte(msgE);

                        sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                        clientSocket.send(sendPacket);

                        //Attendre ACK du serveur 
                        clientSocket.receive(receivePacket);

                        msgR = ByteToMessage(receivePacket.getData());

                        System.out.println("FROM SERVER :" + msgR.toString());
                        this.window.ecrireMessageTrace(" CLIENT " + this.monID + " FROM SERVER :" + msgR.toString());

                        if (msgR.getType() == TypeMessage.ACK) {
                            serveurEnPanne = false;
                        }
                        if (msgR.getType() == TypeMessage.PANNE) {
                            serveurEnPanne = true;
                            this.window.ecrireMessageTrace(" Le SERVEUR " + this.IDServeur + ":  EST EN PANNE !! ");
                        }
                        if (!serveurEnPanne) { // Le serveur n'est pas en panne
                            // Generer la probat de panne 
                            probatP = Math.random();
                            System.out.println(" Probat de panne " + probatP);
                            if (probatP < probatPanne) {
                                System.out.println(this.monID + " Je suis en panne !!");
                                this.window.ecrireMessageTrace(" CLIENT " + this.monID + " : JE EN PANNE !! ");

                                this.JeSuisEnPanne = true;
                                JeSuisEnPanneP.set(true);
                            }

                            // Attendre la réponse du serveur AUT 
                            clientSocket.receive(receivePacket);

                            msgR = ByteToMessage(receivePacket.getData());

                            System.out.println("FROM SERVER :" + msgR.toString());

                            if (msgR.getType() == TypeMessage.AUT) { // En Entre en SC si on reçu l'autorisation 
                                msgR = null; // remettre msgR à null pour la prochaine itération
                                if (JeSuisEnPanne) { // j'envoie un mesg Panne 
                                    msgE.setIdSource(this.monID);
                                    msgE.setIdDestination(this.IDServeur);
                                    msgE.setType(TypeMessage.PANNE);

                                    IPAddressServeur = InetAddress.getLocalHost();
                                    portServeur = Test.IDServeur + Test.Num_portServeur;

                                    msgE.setIPAddressCleint(IPAddressServeur);
                                    msgE.setPortClient(portServeur);

                                    sendData = MessageToByte(msgE);

                                    sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                                    clientSocket.send(sendPacket);
                                } else { // j'envoie un ACK + entrer en SC + enoyer LIB
                                    msgE.setIdSource(this.monID);
                                    msgE.setIdDestination(this.IDServeur);
                                    msgE.setType(TypeMessage.ACK);

                                    IPAddressServeur = InetAddress.getLocalHost();
                                    portServeur = Test.IDServeur + Test.Num_portServeur;

                                    msgE.setIPAddressCleint(IPAddressServeur);
                                    msgE.setPortClient(portServeur);

                                    sendData = MessageToByte(msgE);

                                    sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                                    clientSocket.send(sendPacket);
                                    // Entrer en SC
                                    System.out.println(" Proccessus " + this.monID + " Je suis en SC ");
                                    this.window.ecrireMessageTrace(" CLIENT " + this.monID + " : JE SUIS EN SC :) ");
                                    tempSC = genererAttenteAlétoire(1, 2) * 1000; // génerer un temps d'atente entre 1000 et 2000 ms ;
                                    Thread.sleep(tempSC); // attendre

                                    // Envoyer Lib
                                    msgE.setIdSource(this.monID);
                                    msgE.setIdDestination(this.IDServeur);
                                    msgE.setType(TypeMessage.LIB);

                                    IPAddressServeur = InetAddress.getLocalHost();
                                    portServeur = Test.IDServeur + Test.Num_portServeur;

                                    msgE.setIPAddressCleint(IPAddressServeur);
                                    msgE.setPortClient(portServeur);

                                    sendData = MessageToByte(msgE);

                                    sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                                    clientSocket.send(sendPacket);
                                    this.window.ecrireMessageTrace(" CLIENT " + this.monID + " : JE SUIS SORTIE DE LA SC !! ");
                                }
                            }
                        } else { // Le serveur est en panne --> lancer 'Election"
                            System.out.println(" Client " + this.monID + " : Le SERVEUR " + Test.IDServeur + " est en panne !! ");
                            this.window.ecrireMessageTrace(" CLIENT " + this.monID + " : LE SERVEUR : " + this.IDServeur + " EST EN PANNE !! ");
                            Election();
                            this.serveurEnPanne = false;
                            this.window.ecrireMessageTrace(" CLIENT " + this.monID + " : Nouveau COORDINATEUR : " + this.IDServeur);
                        }
                    }
                }
                //  clientSocket.close();
            }
        } catch (UnknownHostException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SocketException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Message ByteToMessage(byte[] mesgb) {

        String mesg = new String(mesgb);
        Message message = new Message();

        String[] Tmp = mesg.split("-");

        message.setType(TypeMessage.valueOf(Tmp[0]));
        message.setIdSource(Integer.parseInt(Tmp[1]));
        message.setIdDestination(Integer.parseInt(Tmp[2]));

        return message;
    }

    public byte[] MessageToByte(Message message) {
        String message_string = ""; // la chaine a envoyée du serveur vers le client 
        message_string = message_string.concat("" + message.getType() + "-" + message.getIdSource() + "-" + message.getIdDestination() + "-"); // construire le message à envoyer
        // System.out.println(" chaine envoyé "+message_string);
        return message_string.getBytes();
    }

    // la fonction permet de générer un temps d'attente cmpris entre "min" et "max" s 
    public int genererAttenteAlétoire(int minn, int maxx) {
        Random rand = new Random();
        int nombreAleatoire = rand.nextInt(maxx - minn + 1) + minn;
        return nombreAleatoire;
    }

    public void removeProcessFile(int idProcess) {
        if (!this.file.isEmpty()) {
            this.file.remove(Integer.parseInt("0"));
        }
    }

    public ArrayList<processus> getFile() {
        return file;
    }

    // La fonction qui permet de lancer l'operation d'election 
    public void Election() throws InterruptedException {

        try {

            Message MsgR = null;
            Message msgE = new Message(this.monID, 0, TypeMessage.ELECTION); // Le message d'election qui sera envoyé aux processus

            InetAddress IPAddressServeur = InetAddress.getLocalHost();
            int portServeur;
            byte[] sendData;
            DatagramPacket sendPacket;

            this.finElection = false; // réinitialiser l'indicateur de la fin de l'opération d'election
            for (int i = this.monID + 1; i < Test.Nbr_Site; i++) {
                System.out.println(" Client " + this.monID + " Envoie election à --> " + i);
                msgE.setIdSource(this.monID);
                msgE.setIdDestination(i);
                msgE.setType(TypeMessage.ELECTION);

                portServeur = i + Test.Num_portServeur;

                msgE.setIPAddressCleint(IPAddressServeur);
                msgE.setPortClient(portServeur);

                sendData = MessageToByte(msgE);

                sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                clientSocket.send(sendPacket);

                synchronized (this) {
                    this.wait(1000);
                }
            }
            // finElection = vrai si ce processus reçoit un message "coordinateur"
            if (this.nbrRepRecues == 0 && !this.finElection) {
                this.jeSuisCoord = true; // il se declare comme coordinateur

                this.IDServeur = this.monID;
                Test.IDServeur = this.IDServeur;
                for (int i = 0; i < this.monID; i++) {
                    System.out.println(" Client " + this.monID + " Envoie Coordinateur à --> " + i);
                    msgE.setIdSource(this.monID);
                    msgE.setIdDestination(i);
                    msgE.setType(TypeMessage.COORDINATEUR);

                    portServeur = i + Test.Num_portServeur;

                    msgE.setIPAddressCleint(IPAddressServeur);
                    msgE.setPortClient(portServeur);

                    sendData = MessageToByte(msgE);

                    sendPacket = new DatagramPacket(sendData, sendData.length, IPAddressServeur, portServeur);

                    clientSocket.send(sendPacket);
                }
                System.out.println("New Val de cooord " + Test.IDServeur);
            } else {

                System.out.println(" Je ne suis pas le coridnateur :'( ");
                this.jeSuisCoord = false;
            }
            Test.IDServeur = this.IDServeur;
        } catch (UnknownHostException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Site.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void setJeSuisCoord(boolean jeSuisCoord) {
        this.jeSuisCoord = jeSuisCoord;
    }

}
